import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { WorkDataProvider } from './context/WorkDataContext';
import Layout from './components/Layout';
import DailyEntry from './pages/DailyEntry';
import GeneralAccounts from './pages/GeneralAccounts';
import DayDetails from './pages/DayDetails';

function App() {
  return (
    <WorkDataProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<DailyEntry />} />
            <Route path="/accounts" element={<GeneralAccounts />} />
            <Route path="/details" element={<DayDetails />} />
          </Routes>
        </Layout>
      </Router>
    </WorkDataProvider>
  );
}

export default App;