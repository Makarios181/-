import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

// Get Arabic day name from date
export const getDayName = (date: Date): string => {
  return format(date, 'EEEE', { locale: ar });
};

// Format date to Arabic format
export const formatDate = (date: Date): string => {
  return format(date, 'yyyy/MM/dd', { locale: ar });
};

// Generate a unique ID
export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 11);
};

// Format number as currency
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('ar-EG', {
    style: 'decimal',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};