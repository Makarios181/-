export interface WorkDay {
  id: string;
  date: string;
  dayName: string;
  expenses: number;
  received: number;
  notes: string;
  dailyWage: number;
}

export interface WorkDaySummary {
  totalExpenses: number;
  totalReceived: number;
  workDaysCount: number;
  netDue: number;
  dailyWage: number;
}