import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { WorkDay, WorkDaySummary } from '../models/WorkDay';
import { getDayName } from '../utils/dateUtils';

interface WorkDataContextType {
  workDays: WorkDay[];
  summary: WorkDaySummary;
  addWorkDay: (workDay: WorkDay) => void;
  updateWorkDay: (workDay: WorkDay) => void;
  deleteWorkDay: (id: string) => void;
  getWorkDayById: (id: string) => WorkDay | undefined;
}

const WorkDataContext = createContext<WorkDataContextType | undefined>(undefined);

export const useWorkData = () => {
  const context = useContext(WorkDataContext);
  if (context === undefined) {
    throw new Error('useWorkData must be used within a WorkDataProvider');
  }
  return context;
};

interface WorkDataProviderProps {
  children: ReactNode;
}

export const WorkDataProvider = ({ children }: WorkDataProviderProps) => {
  const [workDays, setWorkDays] = useState<WorkDay[]>([]);
  const [summary, setSummary] = useState<WorkDaySummary>({
    totalExpenses: 0,
    totalReceived: 0,
    workDaysCount: 0,
    netDue: 0,
    dailyWage: 0
  });

  useEffect(() => {
    const savedWorkDays = localStorage.getItem('workDays');
    if (savedWorkDays) {
      setWorkDays(JSON.parse(savedWorkDays));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('workDays', JSON.stringify(workDays));
    
    const totalExpenses = workDays.reduce((sum, day) => sum + day.expenses, 0);
    const totalReceived = workDays.reduce((sum, day) => sum + day.received, 0);
    const workDaysCount = workDays.length;
    const dailyWage = workDays.length > 0 ? workDays[0].dailyWage : 0;
    const netDue = (workDaysCount * dailyWage) + totalExpenses - totalReceived;
    
    setSummary({
      totalExpenses,
      totalReceived,
      workDaysCount,
      netDue,
      dailyWage
    });
  }, [workDays]);

  const addWorkDay = (workDay: WorkDay) => {
    const updatedWorkDay = {
      ...workDay,
      dayName: workDay.dayName || getDayName(new Date(workDay.date)),
    };
    
    setWorkDays([...workDays, updatedWorkDay]);
  };

  const updateWorkDay = (updatedWorkDay: WorkDay) => {
    setWorkDays(workDays.map(day => 
      day.id === updatedWorkDay.id ? updatedWorkDay : day
    ));
  };

  const deleteWorkDay = (id: string) => {
    setWorkDays(workDays.filter(day => day.id !== id));
  };

  const getWorkDayById = (id: string) => {
    return workDays.find(day => day.id === id);
  };

  return (
    <WorkDataContext.Provider
      value={{
        workDays,
        summary,
        addWorkDay,
        updateWorkDay,
        deleteWorkDay,
        getWorkDayById,
      }}
    >
      {children}
    </WorkDataContext.Provider>
  );
};