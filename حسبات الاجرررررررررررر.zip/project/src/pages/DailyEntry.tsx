import React, { useState } from 'react';
import { useWorkData } from '../context/WorkDataContext';
import { getDayName, generateId } from '../utils/dateUtils';
import { WorkDay } from '../models/WorkDay';
import DailyWageInput from '../components/DailyWageInput';
import { Save, Calendar, DollarSign, Landmark, FileText } from 'lucide-react';

const DailyEntry = () => {
  const { addWorkDay, workDays } = useWorkData();
  const today = new Date().toISOString().split('T')[0];
  
  const [formData, setFormData] = useState<Omit<WorkDay, 'id' | 'dayName'>>({
    date: today,
    expenses: 0,
    received: 0,
    notes: '',
    dailyWage: workDays.length > 0 ? workDays[0].dailyWage : 0,
  });
  
  const [message, setMessage] = useState({ text: '', type: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'expenses' || name === 'received') {
      setFormData({
        ...formData,
        [name]: parseFloat(value) || 0,
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const dayName = getDayName(new Date(formData.date));
    
    const newWorkDay: WorkDay = {
      id: generateId(),
      dayName,
      ...formData,
    };
    
    addWorkDay(newWorkDay);
    
    // Reset form
    setFormData({
      ...formData,
      expenses: 0,
      received: 0,
      notes: '',
    });
    
    // Show success message
    setMessage({ text: 'تم حفظ البيانات بنجاح', type: 'success' });
    
    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage({ text: '', type: '' });
    }, 3000);
  };

  return (
    <div className="max-w-xl mx-auto">
      <div className="card animate-fadeIn">
        <h2 className="text-xl font-bold text-blue-800 mb-6">إدخال بيانات اليوم</h2>
        
        {message.text && (
          <div className={`mb-4 p-3 rounded-md ${message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {message.text}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="date" className="form-label flex items-center">
              <Calendar className="ml-2 h-4 w-4" />
              التاريخ
            </label>
            <input
              type="date"
              id="date"
              name="date"
              className="input-field"
              value={formData.date}
              onChange={handleChange}
              required
            />
            {formData.date && (
              <p className="mt-1 text-sm text-blue-600">
                {getDayName(new Date(formData.date))}
              </p>
            )}
          </div>
          
          <div className="form-group">
            <label htmlFor="expenses" className="form-label flex items-center">
              <DollarSign className="ml-2 h-4 w-4" />
              المصاريف
            </label>
            <input
              type="number"
              id="expenses"
              name="expenses"
              className="input-field"
              value={formData.expenses || ''}
              onChange={handleChange}
              min="0"
              step="0.01"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="received" className="form-label flex items-center">
              <Landmark className="ml-2 h-4 w-4" />
              الواصل
            </label>
            <input
              type="number"
              id="received"
              name="received"
              className="input-field"
              value={formData.received || ''}
              onChange={handleChange}
              min="0"
              step="0.01"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="notes" className="form-label flex items-center">
              <FileText className="ml-2 h-4 w-4" />
              الملاحظات
            </label>
            <textarea
              id="notes"
              name="notes"
              className="input-field min-h-[100px]"
              value={formData.notes}
              onChange={handleChange}
            />
          </div>
          
          <DailyWageInput />
          
          <button
            type="submit"
            className="btn btn-primary w-full mt-4 flex justify-center items-center"
          >
            <Save className="ml-2 h-5 w-5" />
            حفظ اليوم
          </button>
        </form>
      </div>
    </div>
  );
};

export default DailyEntry;