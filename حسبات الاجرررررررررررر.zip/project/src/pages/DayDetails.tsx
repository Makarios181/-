import React, { useState } from 'react';
import { useWorkData } from '../context/WorkDataContext';
import { formatCurrency } from '../utils/dateUtils';
import { Search, ArrowUpDown, Calendar, DollarSign, CreditCard, FileText, Download } from 'lucide-react';
import * as XLSX from 'xlsx';

const DayDetails = () => {
  const { workDays } = useWorkData();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof typeof workDays[0]>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: keyof typeof workDays[0]) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const exportToExcel = () => {
    const workbookData = sortedAndFilteredDays.map(day => ({
      'التاريخ': day.date,
      'اليوم': day.dayName,
      'المصاريف': day.expenses,
      'الواصل': day.received,
      'الملاحظات': day.notes
    }));

    const worksheet = XLSX.utils.json_to_sheet(workbookData, { 
      header: ['التاريخ', 'اليوم', 'المصاريف', 'الواصل', 'الملاحظات']
    });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'تفاصيل الأيام');
    
    // Auto-size columns
    const maxWidth = workbookData.reduce((w, r) => Math.max(w, Object.values(r).join('').length), 10);
    const colWidth = Math.min(maxWidth, 50);
    worksheet['!cols'] = [ 
      { wch: colWidth }, { wch: colWidth }, { wch: colWidth },
      { wch: colWidth }, { wch: colWidth }
    ];

    XLSX.writeFile(workbook, 'تفاصيل_الأيام.xlsx');
  };

  const sortedAndFilteredDays = [...workDays]
    .filter(day => {
      if (!searchTerm) return true;
      
      const searchTermLower = searchTerm.toLowerCase();
      return (
        day.date.includes(searchTerm) ||
        day.dayName.toLowerCase().includes(searchTermLower) ||
        day.notes.toLowerCase().includes(searchTermLower)
      );
    })
    .sort((a, b) => {
      if (sortField === 'expenses' || sortField === 'received') {
        return sortDirection === 'asc' 
          ? a[sortField] - b[sortField] 
          : b[sortField] - a[sortField];
      }
      
      return sortDirection === 'asc'
        ? String(a[sortField]).localeCompare(String(b[sortField]))
        : String(b[sortField]).localeCompare(String(a[sortField]));
    });

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-blue-800">تفاصيل الأيام</h2>
        <button
          onClick={exportToExcel}
          className="btn btn-secondary flex items-center gap-2"
        >
          <Download className="h-5 w-5" />
          تصدير إلى Excel
        </button>
      </div>
      
      <div className="mb-6 relative">
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
          <Search className="h-5 w-5 text-slate-400" />
        </div>
        <input
          type="text"
          className="input-field pr-10"
          placeholder="ابحث عن تاريخ، يوم، أو ملاحظات..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="card p-0 overflow-hidden">
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th 
                  className="cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort('date')}
                >
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 ml-1" />
                    التاريخ
                    {sortField === 'date' && (
                      <ArrowUpDown className={`h-4 w-4 mr-1 ${sortDirection === 'asc' ? 'transform rotate-180' : ''}`} />
                    )}
                  </div>
                </th>
                <th 
                  className="cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort('dayName')}
                >
                  <div className="flex items-center">
                    اسم اليوم
                    {sortField === 'dayName' && (
                      <ArrowUpDown className={`h-4 w-4 mr-1 ${sortDirection === 'asc' ? 'transform rotate-180' : ''}`} />
                    )}
                  </div>
                </th>
                <th 
                  className="cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort('expenses')}
                >
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 ml-1" />
                    المصاريف
                    {sortField === 'expenses' && (
                      <ArrowUpDown className={`h-4 w-4 mr-1 ${sortDirection === 'asc' ? 'transform rotate-180' : ''}`} />
                    )}
                  </div>
                </th>
                <th 
                  className="cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort('received')}
                >
                  <div className="flex items-center">
                    <CreditCard className="h-4 w-4 ml-1" />
                    الواصل
                    {sortField === 'received' && (
                      <ArrowUpDown className={`h-4 w-4 mr-1 ${sortDirection === 'asc' ? 'transform rotate-180' : ''}`} />
                    )}
                  </div>
                </th>
                <th 
                  className="cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort('notes')}
                >
                  <div className="flex items-center">
                    <FileText className="h-4 w-4 ml-1" />
                    الملاحظات
                    {sortField === 'notes' && (
                      <ArrowUpDown className={`h-4 w-4 mr-1 ${sortDirection === 'asc' ? 'transform rotate-180' : ''}`} />
                    )}
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white">
              {sortedAndFilteredDays.length > 0 ? (
                sortedAndFilteredDays.map(day => (
                  <tr key={day.id} className="hover:bg-slate-50 transition-colors duration-150">
                    <td>{day.date}</td>
                    <td>{day.dayName}</td>
                    <td className="text-red-600 font-medium">{formatCurrency(day.expenses)}</td>
                    <td className="text-green-600 font-medium">{formatCurrency(day.received)}</td>
                    <td className="max-w-[200px] truncate">{day.notes}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-slate-500">
                    لا توجد بيانات لعرضها. قم بإضافة أيام عمل جديدة من صفحة إدخال البيانات.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DayDetails;