import React from 'react';
import { useWorkData } from '../context/WorkDataContext';
import SummaryCard from '../components/SummaryCard';
import { DollarSign, CreditCard, Calendar, PieChart, Briefcase } from 'lucide-react';

const GeneralAccounts = () => {
  const { summary } = useWorkData();
  
  // Calculate excess received (only if net due is negative)
  const excessReceived = summary.netDue < 0 ? Math.abs(summary.netDue) : 0;
  
  // Only show net due if it's positive
  const showNetDue = summary.netDue > 0;

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-xl font-bold text-blue-800 mb-6">الحسابات العامة</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <SummaryCard
          title="إجمالي المصاريف"
          value={summary.totalExpenses}
          icon={<DollarSign className="h-6 w-6" />}
          colorClass="bg-red-600"
        />
        
        <SummaryCard
          title="إجمالي الواصل"
          value={summary.totalReceived}
          icon={<CreditCard className="h-6 w-6" />}
          colorClass="bg-green-600"
        />
        
        <SummaryCard
          title="عدد أيام العمل"
          value={summary.workDaysCount.toString()}
          icon={<Calendar className="h-6 w-6" />}
          colorClass="bg-blue-800"
        />
        
        <SummaryCard
          title="أجر اليوم"
          value={summary.dailyWage}
          icon={<Briefcase className="h-6 w-6" />}
          colorClass="bg-teal-600"
        />
        
        {excessReceived > 0 && (
          <SummaryCard
            title="الواصل الزيادة"
            value={excessReceived}
            icon={<CreditCard className="h-6 w-6" />}
            colorClass="bg-emerald-600"
          />
        )}
      </div>
      
      {showNetDue && (
        <div className="card bg-gradient-to-br from-blue-900 to-blue-800 text-white">
          <div className="flex items-center">
            <div className="bg-white/20 p-4 rounded-full mr-4">
              <PieChart className="h-8 w-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold">الصافي المستحق</h3>
              <p className="text-3xl font-bold mt-2">{new Intl.NumberFormat('ar-EG', {
                style: 'decimal',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              }).format(summary.netDue)}</p>
              <p className="mt-2 text-blue-100 text-sm">
                (عدد الأيام × أجر اليوم + إجمالي المصاريف - إجمالي الواصل)
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneralAccounts;