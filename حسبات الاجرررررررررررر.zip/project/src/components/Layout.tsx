import React, { ReactNode } from 'react';
import { NavLink } from 'react-router-dom';
import { ClipboardList, Calculator, Calendar } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold text-blue-800">حساب الأجر</h1>
        </div>
      </header>
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="animate-fadeIn">{children}</div>
      </main>
      
      <nav className="sticky bottom-0 bg-white shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] border-t border-slate-200">
        <div className="container mx-auto">
          <ul className="flex justify-around">
            <li className="flex-1">
              <NavLink 
                to="/" 
                className={({ isActive }) => 
                  `flex flex-col items-center py-3 transition-colors duration-200 ${isActive ? 'tab-active' : 'tab-inactive'}`
                }
              >
                <Calendar className="h-6 w-6 mb-1" />
                <span className="text-xs">إدخال البيانات</span>
              </NavLink>
            </li>
            <li className="flex-1">
              <NavLink 
                to="/accounts" 
                className={({ isActive }) => 
                  `flex flex-col items-center py-3 transition-colors duration-200 ${isActive ? 'tab-active' : 'tab-inactive'}`
                }
              >
                <Calculator className="h-6 w-6 mb-1" />
                <span className="text-xs">الحسابات العامة</span>
              </NavLink>
            </li>
            <li className="flex-1">
              <NavLink 
                to="/details" 
                className={({ isActive }) => 
                  `flex flex-col items-center py-3 transition-colors duration-200 ${isActive ? 'tab-active' : 'tab-inactive'}`
                }
              >
                <ClipboardList className="h-6 w-6 mb-1" />
                <span className="text-xs">تفاصيل الأيام</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default Layout;