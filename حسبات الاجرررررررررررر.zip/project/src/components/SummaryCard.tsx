import React from 'react';
import { formatCurrency } from '../utils/dateUtils';

interface SummaryCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  colorClass?: string;
}

const SummaryCard = ({ title, value, icon, colorClass = 'bg-blue-800' }: SummaryCardProps) => {
  return (
    <div className="card transition-all duration-300 hover:shadow-lg">
      <div className="flex items-center">
        <div className={`${colorClass} p-3 rounded-full text-white mr-4`}>
          {icon}
        </div>
        <div>
          <h3 className="text-lg font-semibold text-slate-700">{title}</h3>
          <p className="text-2xl font-bold mt-1">{typeof value === 'number' ? formatCurrency(value) : value}</p>
        </div>
      </div>
    </div>
  );
};

export default SummaryCard;