import React, { useState, useEffect } from 'react';
import { useWorkData } from '../context/WorkDataContext';

const DailyWageInput = () => {
  const { workDays, addWorkDay, updateWorkDay } = useWorkData();
  const [dailyWage, setDailyWage] = useState<number>(0);
  
  useEffect(() => {
    // Get daily wage from the first record if exists
    if (workDays.length > 0 && workDays[0].dailyWage) {
      setDailyWage(workDays[0].dailyWage);
    }
  }, [workDays]);

  const handleDailyWageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDailyWage = parseFloat(e.target.value);
    setDailyWage(newDailyWage);
    
    // If we have work days, update all with the new daily wage
    if (workDays.length > 0) {
      workDays.forEach(day => {
        updateWorkDay({ ...day, dailyWage: newDailyWage });
      });
    }
  };

  return (
    <div className="form-group">
      <label htmlFor="dailyWage" className="form-label">أجر اليوم</label>
      <input
        type="number"
        id="dailyWage"
        className="input-field"
        value={dailyWage || ''}
        onChange={handleDailyWageChange}
        min="0"
        step="0.01"
      />
    </div>
  );
};

export default DailyWageInput;